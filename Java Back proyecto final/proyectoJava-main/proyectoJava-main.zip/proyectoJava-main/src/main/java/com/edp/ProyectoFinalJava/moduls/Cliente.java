package com.edp.ProyectoFinalJava.moduls;

public interface Cliente {
    void realizarCompra(Vendible producto);
}