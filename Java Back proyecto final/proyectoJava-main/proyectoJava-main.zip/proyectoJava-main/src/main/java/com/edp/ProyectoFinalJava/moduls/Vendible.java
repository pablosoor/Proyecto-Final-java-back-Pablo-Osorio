package com.edp.ProyectoFinalJava.moduls;

public interface Vendible {
    double calcularPrecio();
}
